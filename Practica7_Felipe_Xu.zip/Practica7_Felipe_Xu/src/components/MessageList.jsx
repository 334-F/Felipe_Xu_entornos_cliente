import React from 'react';

// Uso de props para recibir los mensajes del padre
function MessageList({ mensajes }) {
  // Renderización condicional
  if (mensajes.length === 0) {
    return <p style={{ textAlign: 'center', color: '#888' }}>El historial está vacío. ¡Haz una pregunta!</p>;
  }

  return (
    <div style={{ padding: '15px', backgroundColor: '#f9f9f9', borderRadius: '8px', minHeight: '200px' }}>
      {/* Recorrer colecciones con map */}
      {mensajes.map((msg, index) => (
        <div key={index} style={{ marginBottom: '15px', paddingBottom: '10px', borderBottom: '1px solid #ddd' }}>
          <p style={{ margin: '0 0 5px 0' }}><strong>Tú:</strong> {msg.usuario}</p>
          <p style={{ margin: '0', color: '#0066cc' }}><strong>Asistente:</strong> {msg.asistente}</p>
          {msg.categoria && (
            <small style={{ color: '#777', display: 'block', marginTop: '5px' }}>
              Categoría: {msg.categoria.toUpperCase()}
            </small>
          )}
        </div>
      ))}
    </div>
  );
}

export default MessageList;