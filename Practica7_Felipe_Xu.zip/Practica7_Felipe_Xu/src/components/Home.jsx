import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '50px', fontFamily: 'Arial' }}>
      <h1>Asistente de Componentes de PC</h1>
      <p>Tu ingeniero de hardware virtual personal.</p>
      
      <Link to="/chat">
        <button style={{ padding: '10px 20px', fontSize: '16px', backgroundColor: '#0066cc', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
          Iniciar Asistente
        </button>
      </Link>
    </div>
  );
}

export default Home;