import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import MessageList from './MessageList';
import datosIniciales from '../datos.json'; 

function Chat() {
  // Manejo de estado con useState
  const [mensajes, setMensajes] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [cargando, setCargando] = useState(true);

  // Ciclo de vida con useEffect para simular carga de datos
  useEffect(() => {
    const timer = setTimeout(() => {
      setMensajes(datosIniciales);
      setCargando(false);
    }, 1000); 
    return () => clearTimeout(timer);
  }, []);

  // Manejo de eventos
  const handleEnviar = () => {
    if (inputValue.trim() === '') return;
    const nuevoMensaje = {
      id: Date.now(),
      usuario: inputValue,
      asistente: "Consulta recibida. Como asistente virtual, te recomiendo verificar la compatibilidad de ese componente.",
      categoria: "nueva consulta"
    };
    setMensajes([...mensajes, nuevoMensaje]);
    setInputValue(''); 
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'Arial' }}>
      <Link to="/" style={{ textDecoration: 'none', color: '#0066cc', fontWeight: 'bold' }}>← Volver</Link>
      <h2 style={{ marginTop: '20px' }}>Chat de Hardware</h2>

      {cargando ? (
        <div style={{ textAlign: 'center', padding: '50px', color: '#555' }}>⏳ Conectando con la base de datos...</div>
      ) : (
        <>
          <MessageList mensajes={mensajes} />
          <div style={{ marginTop: '20px', display: 'flex', gap: '10px' }}>
            <input 
              type="text" 
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Escribe tu pregunta..."
              style={{ flex: 1, padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
            />
            <button onClick={handleEnviar} style={{ padding: '10px 20px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
              Enviar
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Chat;